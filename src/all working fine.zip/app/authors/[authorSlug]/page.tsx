import axios from 'axios';
import Link from 'next/link';

type Author = {
  id: string;
  name: string;
  slug: string;
  bio?: string;
};

type Category = {
  id: string;
  slug: string;
  title?: string;
  parent?: { id: string; slug: string; title: string } | string;
};

type Post = {
  id: string;
  title: string;
  slug: string;
  publishedAt: string;
  meta?: {
    description?: string;
  };
  tags?: { id: string; title: string; slug: string }[];
  layout?: {
    blockType: string;
    media?: {
      url: string;
      alt?: string;
    };
  }[];
  categories?: Category[];
};

const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000';

async function fetchAuthors(): Promise<Author[]> {
  try {
    const res = await axios.get(`${apiUrl}/api/users?depth=1`);
    const authors = res.data.docs || [];
    console.log('Fetched authors:', authors);
    return authors;
  } catch (err) {
    console.error('Error fetching authors:', err.response?.data || err.message);
    return [];
  }
}

async function fetchAuthorBySlug(slug: string): Promise<Author | null> {
  try {
    const lowercaseSlug = slug.toLowerCase();
    const res = await axios.get(`${apiUrl}/api/users?where[slug][equals]=${lowercaseSlug}&depth=1`);
    const author = res.data.docs[0] || null;
    if (!author) {
      console.log(`No author found for slug: ${lowercaseSlug}`);
    } else {
      console.log(`Fetched author with slug ${lowercaseSlug}:`, author);
    }
    return author;
  } catch (err) {
    console.error(`Error fetching author with slug ${slug}:`, err.response?.data || err.message);
    return null;
  }
}

async function fetchPostsByAuthor(authorId: string, page: number = 1, limit: number = 10): Promise<{ posts: Post[]; total: number }> {
  try {
    const res = await axios.get(
      `${apiUrl}/api/posts?limit=${limit}&page=${page}&depth=3&where[authors][contains]=${authorId}`
    );
    console.log(`Fetched ${res.data.docs.length} posts for author ID ${authorId}`);
    return {
      posts: res.data.docs || [],
      total: res.data.totalDocs || 0,
    };
  } catch (err) {
    console.error(`Error fetching posts for author ID ${authorId}:`, err.response?.data || err.message);
    return { posts: [], total: 0 };
  }
}

async function fetchParentCategory(parentId: string): Promise<{ slug: string; title: string } | null> {
  try {
    const res = await axios.get(`${apiUrl}/api/categories/${parentId}?depth=1`);
    const parentCategory = res.data || null;
    if (!parentCategory) {
      console.log(`No parent category found for ID: ${parentId}`);
      return null;
    }
    return {
      slug: parentCategory.slug || 'uncategorized',
      title: parentCategory.title || 'Uncategorized',
    };
  } catch (err) {
    console.error(`Error fetching parent category with ID ${parentId}:`, err.response?.data || err.message);
    return null;
  }
}

export default async function AuthorPage({
  params,
  searchParams,
}: {
  params: { authorSlug: string };
  searchParams: { page?: string };
}) {
  const page = parseInt(searchParams.page || '1', 10);
  const limit = 10;

  const author = await fetchAuthorBySlug(params.authorSlug);

  if (!author) {
    return (
      <div className="container mx-auto px-4 py-12 text-center text-gray-500">
        Author not found. Please check if the author exists or try a different slug.
      </div>
    );
  }

  const { posts, total } = await fetchPostsByAuthor(author.id, page, limit);
  const totalPages = Math.ceil(total / limit);

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mb-12 border-b pb-6">
        <h1 className="text-4xl font-bold text-gray-900 mb-3 capitalize">{author.name}</h1>
        {author.bio && (
          <p className="text-lg text-gray-600 max-w-3xl leading-relaxed">{author.bio}</p>
        )}
      </div>

      {posts.length === 0 ? (
        <p className="text-gray-500 text-center">No posts found by this author.</p>
      ) : (
        <>
          <div className="space-y-8 mb-12">
            {await Promise.all(
              posts.map(async (post) => {
                const mediaBlock = post.layout?.find(
                  (block) => block.blockType === 'mediaBlock'
                );
                const imageUrl = mediaBlock?.media?.url;
                const imageAlt = mediaBlock?.media?.alt || post.title;

                const category = post.categories?.[0];
                let parentCategorySlug = 'uncategorized';
                let parentCategoryTitle = 'Uncategorized';
                const categorySlug = category?.slug || 'uncategorized';
                const categoryTitle = category?.title || 'Uncategorized';

                if (category?.parent) {
                  const parent = typeof category.parent === 'string'
                    ? await fetchParentCategory(category.parent)
                    : category.parent;
                  if (parent) {
                    parentCategorySlug = parent.slug || 'uncategorized';
                    parentCategoryTitle = parent.title || 'Uncategorized';
                  }
                }

                return (
                  <Link
                    key={post.id}
                    href={`/${parentCategorySlug}/${categorySlug}/${post.slug}`}
                    className="flex flex-col md:flex-row gap-4 border-b pb-6 hover:bg-gray-50 transition"
                  >
                    {imageUrl && (
                      <div className="md:w-1/4">
                        <img
                          src={imageUrl}
                          alt={imageAlt}
                          className="rounded-lg w-full h-32 object-cover"
                        />
                      </div>
                    )}
                    <div className="flex-1">
                      <div className="text-sm text-indigo-600 mb-1">
                        <Link href={`/${parentCategorySlug}/${categorySlug}`} className="hover:underline">
                          {parentCategoryTitle} > {categoryTitle}
                        </Link>
                      </div>
                      <h2 className="text-xl font-semibold text-gray-900 mb-2 hover:text-indigo-600 transition">
                        {post.title}
                      </h2>
                      {post.meta?.description && (
                        <p className="text-gray-600 mb-3 text-sm line-clamp-2">
                          {post.meta.description}
                        </p>
                      )}
                      <div className="text-sm text-gray-500 mb-2">
                        {new Date(post.publishedAt).toLocaleDateString('en-US', {
                          day: 'numeric',
                          month: 'short',
                          year: 'numeric',
                        })}
                      </div>
                      {post.tags?.length > 0 && (
                        <div className="flex flex-wrap gap-2">
                          {post.tags.slice(0, 2).map((tag) => (
                            <Link key={tag.id} href={`/tags/${tag.slug}`}>
                              <span className="inline-block bg-gray-100 rounded-full px-3 py-1 text-sm font-semibold text-gray-700 hover:bg-gray-200 transition">
                                #{tag.title}
                              </span>
                            </Link>
                          ))}
                        </div>
                      )}
                    </div>
                  </Link>
                );
              })
            )}
          </div>

          {totalPages > 1 && (
            <div className="flex justify-center space-x-2">
              {page > 1 && (
                <Link
                  href={`/authors/${params.authorSlug}?page=${page - 1}`}
                  className="px-4 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300"
                >
                  Previous
                </Link>
              )}
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((pageNum) => (
                <Link
                  key={pageNum}
                  href={`/authors/${params.authorSlug}?page=${pageNum}`}
                  className={`px-4 py-2 rounded ${
                    page === pageNum
                      ? 'bg-indigo-600 text-white'
                      : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                  }`}
                >
                  {pageNum}
                </Link>
              ))}
              {page < totalPages && (
                <Link
                  href={`/authors/${params.authorSlug}?page=${page + 1}`}
                  className="px-4 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300"
                >
                  Next
                </Link>
              )}
            </div>
          )}
        </>
      )}
    </div>
  );
}

export async function generateStaticParams() {
  const authors = await fetchAuthors();
  const validAuthors = authors.filter((author: Author) => {
    if (!author.slug || typeof author.slug !== 'string') {
      console.warn(`Skipping author with invalid slug:`, author);
      return false;
    }
    return true;
  });

  return validAuthors.map((author: Author) => ({
    authorSlug: author.slug,
  }));
}