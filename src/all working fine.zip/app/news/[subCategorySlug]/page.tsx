// src/app/news/[subCategorySlug]/page.tsx

import axios from "axios";
import Link from "next/link";
import { Space } from "antd";
import { ClockCircleOutlined } from "@ant-design/icons";
import Text from "antd/es/typography/Text";
import { notFound } from "next/navigation";

// Type definitions
type Category = {
  id: string;
  title: string;
  slug: string;
  parent?: { id: string; slug: string; title: string } | string | null;
};

type Post = {
  id: string;
  title: string;
  slug: string;
  publishedAt: string;
  meta?: {
    description?: string;
  };
  tags?: { id: string; title: string; slug: string }[];
  layout?: {
    blockType: string;
    media?: {
      url: string;
      alt?: string;
    };
  }[];
};

// API base URL
const apiUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:3000";

// Fetch a category by slug
async function fetchCategoryBySlug(slug: string): Promise<Category | null> {
  try {
    console.log(`Fetching category with slug: ${slug}`);
    const response = await axios.get(
      `${apiUrl}/api/categories?where[slug][equals]=${slug}&depth=2`
    );
    const category = response.data.docs[0] || null;
    if (!category) {
      console.log(`No category found for slug: ${slug}`);
      return null;
    }
    console.log(`Fetched category ${slug}:`, JSON.stringify(category, null, 2));
    return category;
  } catch (error) {
    console.error(
      `Error fetching category with slug ${slug}:`,
      error.response?.data || error.message
    );
    return null;
  }
}

// Fetch parent category details by ID
async function fetchParentCategory(
  parentId: string
): Promise<{ slug: string; title: string } | null> {
  try {
    console.log(`Fetching parent category with ID: ${parentId}`);
    const res = await axios.get(`${apiUrl}/api/categories/${parentId}?depth=1`);
    const parentCategory = res.data || null;
    if (!parentCategory) {
      console.log(`No parent category found for ID: ${parentId}`);
      return null;
    }
    console.log(`Fetched parent category:`, JSON.stringify(parentCategory, null, 2));
    return {
      slug: parentCategory.slug || "uncategorized",
      title: parentCategory.title || "Uncategorized",
    };
  } catch (err) {
    console.error(
      `Error fetching parent category with ID ${parentId}:`,
      err.response?.data || err.message
    );
    return null;
  }
}

// Fetch posts by category
async function fetchPostsByCategory(categoryId: string, limit: number = 10): Promise<Post[]> {
  try {
    console.log(`Fetching posts for category ID: ${categoryId}`);
    const res = await axios.get(
      `${apiUrl}/api/posts?limit=${limit}&depth=2&where[categories][contains]=${categoryId}`
    );
    console.log(`Fetched ${res.data.docs.length} posts for category ID ${categoryId}`);
    return res.data.docs || [];
  } catch (err) {
    console.error(`Error fetching posts for category ID ${categoryId}:`, err.response?.data || err.message);
    return [];
  }
}

// Main SubCategoryPage component
export default async function SubCategoryPage({
  params,
}: {
  params: Promise<{ subCategorySlug: string }>;
}) {
  console.log("Entering SubCategoryPage component for /news/[subCategorySlug]");

  const { subCategorySlug } = await params;
  const categorySlug = "news"; // Hardcoded since this route is under /news
  console.log(`Handling subcategory page for ${categorySlug}/${subCategorySlug}`);

  // Fetch the subcategory
  const subCategory = await fetchCategoryBySlug(subCategorySlug);
  if (!subCategory) {
    console.log(`Subcategory not found for slug: ${subCategorySlug}`);
    notFound();
  }

  // Verify the parent category
  let parentCategorySlug = "uncategorized";
  let parentCategoryTitle = "Uncategorized";

  if (!subCategory.parent) {
    console.log(`Subcategory ${subCategorySlug} has no parent, this route should not be used for top-level categories`);
    notFound();
  }

  const parent = typeof subCategory.parent === "string"
    ? await fetchParentCategory(subCategory.parent)
    : subCategory.parent;
  if (parent) {
    parentCategorySlug = parent.slug;
    parentCategoryTitle = parent.title;
    console.log(
      `Parent category for subcategory ${subCategorySlug}: ${parentCategorySlug} (${parentCategoryTitle})`
    );
  } else {
    console.log(
      `Parent category not found for subcategory ${subCategorySlug}, using defaults`
    );
  }

  // Check if the parent category matches the expected "news"
  if (parentCategorySlug !== categorySlug) {
    console.warn(
      `Parent category mismatch: expected ${categorySlug}, but found ${parentCategorySlug} for subcategory ${subCategorySlug}.`
    );
    notFound();
  }

  // Fetch posts for this subcategory
  const posts = await fetchPostsByCategory(subCategory.id);

  return (
    <div
      className="container mx-auto px-4 sm:px-6 lg:px-8 py-12"
      style={{ maxWidth: "1200px", margin: "0px auto", padding: "0px 16px" }}
    >
      {/* Breadcrumbs */}
      <nav
        aria-label="Breadcrumb"
        className="mb-6 text-sm font-medium text-gray-600"
      >
        <div className="flex items-center space-x-2 breadcrumbs">
          <span>
            <Link
              href="/"
              className="text-indigo-600 hover:underline transition-colors"
            >
              Home
            </Link>
          </span>
          <span className="text-gray-400">/</span>
          <span>
            <Link
              href={`/${parentCategorySlug}`}
              className="text-indigo-600 hover:underline transition-colors"
            >
              {parentCategoryTitle}
            </Link>
          </span>
          <span className="text-gray-400">/</span>
          <span className="text-gray-800">{subCategory.title}</span>
        </div>
      </nav>

      <h1
        className="text-3xl font-bold mb-8 capitalize"
        style={{ borderLeft: "5px solid #333", paddingLeft: "10px" }}
      >
        {subCategory.title}
      </h1>

      {posts.length === 0 ? (
        <p className="text-gray-500">No posts found in this subcategory.</p>
      ) : (
        <div className="category-grid">
          {posts.map((post) => {
            const mediaBlock = post.layout?.find(
              (block) => block.blockType === "mediaBlock"
            );
            const imageUrl = mediaBlock?.media?.url;
            const imageAlt = mediaBlock?.media?.alt || post.title;

            return (
              <Link
                key={post.id}
                href={`/${categorySlug}/${subCategorySlug}/${post.slug}`}
                className="flex gap-4 py-4 hover:bg-gray-50 transition-all"
              >
                <div className="post-item-category api-title">
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold mb-1 text-gray-800 hover:text-blue-600 transition">
                      {post.title}
                    </h3>
                    {post.meta?.description && (
                      <p className="text-gray-600 mb-2 line-clamp-2 text-sm">
                        {post.meta.description}
                      </p>
                    )}
                    <div className="post-first-tag">
                      {post.tags?.length > 0 && (
                        <Link href={`/tags/${post.tags[0].slug}`}>
                          <span className="text-blue-600 hover:underline">
                            {post.tags[0].title}
                          </span>
                        </Link>
                      )}
                      <span style={{ marginTop: "4px" }}>
                        <Space size={4}>
                          <ClockCircleOutlined
                            style={{ fontSize: "12px", color: "#8c8c8c" }}
                          />
                          <Text type="secondary" style={{ fontSize: "12px" }}>
                            5 Min Read
                          </Text>
                        </Space>
                      </span>
                      <span className="shareButton" data-url="">
                        <svg
                          width="22"
                          height="18"
                          viewBox="0 0 22 18"
                          fill="none"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <g clipPath="url(#clip0_4600_28)">
                            <path
                              d="M0.656855 18.3763C0.57123 18.3767 0.486122 18.363 0.40498 18.3356C0.235292 18.2805 0.088454 18.1711 -0.0128684 18.0243C-0.114191 17.8774 -0.164364 17.7013 -0.155645 17.5231C-0.155645 17.4013 0.68123 5.60375 12.5112 4.6775V0.436251C12.5111 0.274716 12.5591 0.116806 12.6491 -0.0173126C12.7392 -0.151431 12.8671 -0.255668 13.0167 -0.316712C13.1662 -0.377755 13.3306 -0.392834 13.4888 -0.360022C13.6469 -0.32721 13.7917 -0.247996 13.9047 -0.132499L21.924 8.0575C22.0729 8.20938 22.1563 8.41358 22.1563 8.62625C22.1563 8.83893 22.0729 9.04312 21.924 9.195L13.9047 17.385C13.7917 17.5005 13.6469 17.5797 13.4888 17.6125C13.3306 17.6453 13.1662 17.6303 13.0167 17.5692C12.8671 17.5082 12.7392 17.4039 12.6491 17.2698C12.5591 17.1357 12.5111 16.9778 12.5112 16.8163V12.6563C4.61373 12.9569 1.37592 17.9375 1.34342 17.9984C1.27012 18.1142 1.16873 18.2095 1.0487 18.2756C0.928659 18.3416 0.793867 18.3763 0.656855 18.3763ZM14.1362 2.42688V5.43719C14.1364 5.64784 14.0547 5.85031 13.9084 6.00189C13.7621 6.15347 13.5627 6.24232 13.3522 6.24969C5.69842 6.53 2.96029 11.6284 1.97717 14.9069C4.00842 13.1519 7.6281 11.0069 13.275 11.0069H13.3115C13.527 11.0069 13.7337 11.0925 13.8861 11.2449C14.0384 11.3972 14.124 11.6039 14.124 11.8194V14.8297L20.2178 8.63031L14.1362 2.42688Z"
                              fill="#A0A0A0"
                            />
                          </g>
                          <defs>
                            <clipPath id="clip0_4600_28">
                              <rect width="22" height="18" fill="white" />
                            </clipPath>
                          </defs>
                        </svg>
                      </span>
                    </div>
                  </div>
                  {imageUrl && (
                    <div className="w-1/3">
                      <img
                        src={imageUrl}
                        alt={imageAlt}
                        className="w-full h-32 object-cover rounded"
                      />
                    </div>
                  )}
                </div>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}

// Generate static parameters for Next.js static generation
export async function generateStaticParams() {
  console.log("Entering generateStaticParams for news/[subCategorySlug]");

  try {
    // Fetch subcategories where the parent slug is "news"
    const res = await axios.get(
      `${apiUrl}/api/categories?where[parent][exists]=true&limit=100&depth=2`
    );
    const categories = res.data.docs || [];
    console.log(`Fetched ${categories.length} subcategories for static generation:`, JSON.stringify(categories, null, 2));

    const params = [];
    for (const category of categories) {
      const parent = typeof category.parent === "string"
        ? await fetchParentCategory(category.parent)
        : category.parent;
      if (parent && parent.slug === "news" && category.slug) {
        const param = {
          subCategorySlug: category.slug,
        };
        params.push(param);
        console.log(`Generated static param for subcategory: news/${category.slug}`);
      } else {
        console.log(`Skipping category ${category.slug}: parent is not "news" or invalid slug`);
      }
    }

    console.log("Generated static params for subcategories:", JSON.stringify(params, null, 2));
    return params;
  } catch (error) {
    console.error(
      "Error generating static params for subcategories:",
      error.response?.data || error.message
    );
    return [];
  }
}