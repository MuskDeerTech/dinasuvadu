import axios from "axios";
import Link from "next/link";
import { Card, Space } from "antd";
import { ClockCircleOutlined } from "@ant-design/icons";
import Text from "antd/es/typography/Text";
import { notFound } from "next/navigation";

// Type definitions
type RichTextChild = {
  text: string;
  bold?: boolean;
  italic?: boolean;
};

type RichTextBlock = {
  children: RichTextChild[];
};

type LayoutBlock = {
  blockType: string;
  media?: {
    url: string;
    alt?: string;
    width?: number;
    height?: number;
    caption?: string;
  };
  content?: string;
};

type Tag = {
  id: string;
  title: string;
  slug: string;
};

type Author = {
  id: string;
  name: string;
  slug: string;
};

type Category = {
  id: string;
  title?: string;
  slug: string;
  parent?: { id: string; slug: string; title: string } | string | null;
};

type Post = {
  id: string;
  title: string;
  slug: string;
  publishedAt: string;
  layout?: LayoutBlock[];
  hero?: {
    type: string;
    richText?: RichTextBlock[];
    links?: any[];
  };
  meta?: {
    description?: string;
    image?: {
      url: string;
      alt?: string;
    };
  };
  categories?: Category[];
  populatedAuthors?: Author[];
  tags?: Tag[];
};

// API base URL
const apiUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:3000";

// Fetch a category by slug
async function fetchCategoryBySlug(slug: string): Promise<Category | null> {
  try {
    console.log(`Fetching category with slug: ${slug}`);
    const response = await axios.get(
      `${apiUrl}/api/categories?where[slug][equals]=${slug}&depth=2`
    );
    const category = response.data.docs[0] || null;
    if (!category) {
      console.log(`No category found for slug: ${slug}`);
      return null;
    }
    console.log(`Fetched category ${slug}:`, JSON.stringify(category, null, 2));
    return category;
  } catch (error) {
    console.error(
      `Error fetching category with slug ${slug}:`,
      error.response?.data || error.message
    );
    return null;
  }
}

// Fetch parent category details by ID
async function fetchParentCategory(
  parentId: string
): Promise<{ slug: string; title: string } | null> {
  try {
    console.log(`Fetching parent category with ID: ${parentId}`);
    const res = await axios.get(`${apiUrl}/api/categories/${parentId}?depth=1`);
    const parentCategory = res.data || null;
    if (!parentCategory) {
      console.log(`No parent category found for ID: ${parentId}`);
      return null;
    }
    console.log(`Fetched parent category:`, JSON.stringify(parentCategory, null, 2));
    return {
      slug: parentCategory.slug || "uncategorized",
      title: parentCategory.title || "Uncategorized",
    };
  } catch (err) {
    console.error(
      `Error fetching parent category with ID ${parentId}:`,
      err.response?.data || err.message
    );
    return null;
  }
}

// Fetch a single post by slug
async function fetchPost(slug: string): Promise<Post | null> {
  try {
    console.log(`Fetching post with slug: ${slug}`);
    const response = await axios.get(
      `${apiUrl}/api/posts?where[slug][equals]=${slug}&depth=2`
    );
    console.log(`API response for post slug ${slug}:`, response.data);
    const post = response.data.docs[0] || null;
    if (!post) {
      console.log(`No post found for slug: ${slug}`);
    } else {
      console.log(`Found post: ${post.title} (slug: ${slug})`);
    }
    return post;
  } catch (error) {
    console.error(
      "Error fetching post with slug " + slug + ":",
      error.response?.data || error.message
    );
    return null;
  }
}

// Fetch the latest posts (excluding the current post)
async function fetchLatestPosts(currentPostSlug: string): Promise<Post[]> {
  try {
    console.log(`Fetching latest posts excluding slug: ${currentPostSlug}`);
    const response = await axios.get(
      `${apiUrl}/api/posts?limit=5&sort=-publishedAt&where[slug][not_equals]=${currentPostSlug}&depth=2`
    );
    const posts = response.data.docs || [];
    console.log(`Fetched ${posts.length} latest posts`);
    return posts;
  } catch (error) {
    console.error(
      "Error fetching latest posts:",
      error.response?.data || error.message
    );
    return [];
  }
}

// Fetch category details by ID
async function fetchCategoryById(
  categoryId: string
): Promise<{ title: string } | null> {
  try {
    console.log(`Fetching category with ID: ${categoryId}`);
    const res = await axios.get(
      `${apiUrl}/api/categories/${categoryId}?depth=1`
    );
    const category = res.data || null;
    if (!category) {
      console.log(`No category found for ID: ${categoryId}`);
      return null;
    }
    console.log(`Fetched category by ID:`, JSON.stringify(category, null, 2));
    return {
      title: category.title || "Uncategorized",
    };
  } catch (err) {
    console.error(
      `Error fetching category with ID ${categoryId}:`,
      err.response?.data || err.message
    );
    return null;
  }
}

// Define the clamping style for text overflow
const clampStyle = {
  display: "-webkit-box",
  WebkitLineClamp: 3,
  WebkitBoxOrient: "vertical",
  overflow: "hidden",
  textOverflow: "ellipsis",
  lineHeight: "1.4",
};

// Main PostPage component
export default async function PostPage({
  params,
}: {
  params: Promise<{ slug: string[] }>;
}) {
  console.log("Entering PostPage component");

  const { slug } = await params; // Await params for Next.js 15
  console.log(`Handling slug: ${slug.join("/")}`);

  // Validate slug length
  if (slug.length !== 2 && slug.length !== 3) {
    console.log(`Invalid slug length: ${slug.length}, slug: ${slug.join("/")}`);
    notFound();
  }

  let categorySlug: string;
  let subCategorySlug: string | null = null;
  let postSlug: string;
  let category: Category | null;
  let parentCategory: { slug: string; title: string } | null = null;

  if (slug.length === 2) {
    // Case: /cinema/post-slug
    categorySlug = slug[0]; // e.g., "cinema"
    postSlug = slug[1]; // e.g., "post-slug"
  } else {
    // Case: /news/tamilnadu/post-slug
    categorySlug = slug[0]; // e.g., "news"
    subCategorySlug = slug[1]; // e.g., "tamilnadu"
    postSlug = slug[2]; // e.g., "post-slug"
  }

  // Fetch the post
  const post = await fetchPost(postSlug);
  if (!post) {
    console.log(`Post not found for slug: ${postSlug}`);

    // If slug.length === 2, check if the second segment is a subcategory
    if (slug.length === 2) {
      const possibleSubCategory = await fetchCategoryBySlug(postSlug);
      if (possibleSubCategory && possibleSubCategory.parent) {
        const parent = typeof possibleSubCategory.parent === "string"
          ? await fetchParentCategory(possibleSubCategory.parent)
          : possibleSubCategory.parent;
        console.log(
          `Slug ${postSlug} is a subcategory with parent ${parent?.slug}. Deferring to ${parent?.slug}/[subCategorySlug]/page.tsx`
        );
        notFound(); // Let Next.js fall back to the subcategory route
      }
    }
    notFound();
  }

  // Get the post's category with a fallback
  let postCategory: Category | null = post.categories?.[0] || null;
  if (!postCategory) {
    console.log(`Post ${postSlug} has no associated category, using default`);
    postCategory = { id: "default", slug: "uncategorized", title: "Uncategorized" };
  }

  // Fetch the category (subCategorySlug if present, otherwise categorySlug)
  category = await fetchCategoryBySlug(subCategorySlug || categorySlug);
  if (!category) {
    console.log(`Category ${subCategorySlug || categorySlug} not found, using post's category`);
    category = postCategory;
  }

  // Ensure category is not null
  if (!category) {
    console.log(`No valid category found for ${subCategorySlug || categorySlug}, using default`);
    category = { id: "default", slug: "uncategorized", title: "Uncategorized" };
  }

  // Fetch category title for breadcrumbs
  let categoryTitle = category.title || "Uncategorized";
  if (!category.title) {
    const fetchedCategory = await fetchCategoryById(category.id);
    if (fetchedCategory) {
      categoryTitle = fetchedCategory.title;
    }
  }

  let parentCategorySlug = "uncategorized";
  let parentCategoryTitle = "Uncategorized";

  // Check for parent category only if necessary
  if (category.parent && slug.length === 3) {
    parentCategory = typeof category.parent === "string"
      ? await fetchParentCategory(category.parent)
      : category.parent;
    if (parentCategory) {
      parentCategorySlug = parentCategory.slug || "uncategorized";
      parentCategoryTitle = parentCategory.title || "Uncategorized";
    } else {
      console.log(`Parent category not found for category ${subCategorySlug}`);
      parentCategorySlug = categorySlug;
      parentCategoryTitle = categoryTitle;
    }
  }

  // Fetch latest posts for the sidebar
  const latestPosts = await fetchLatestPosts(postSlug);

  // Render the page
  return (
    <div
      className="container mx-auto px-4 sm:px-6 lg:px-8 py-12"
      style={{ maxWidth: "1200px", margin: "0px auto", padding: "0px 16px" }}
    >
      <div className="post-grid lg:grid lg:grid-cols-3 lg:gap-8">
        {/* Main Article Content */}
        <article className="lg:col-span-2">
          {/* Breadcrumbs */}
          <nav
            aria-label="Breadcrumb"
            className="mb-6 text-sm font-medium text-gray-600"
          >
            <div className="flex items-center space-x-2 breadcrumbs">
              <span>
                <Link
                  href="/"
                  className="text-indigo-600 hover:underline transition-colors"
                >
                  Home
                </Link>
              </span>
              {category.parent && parentCategory && slug.length === 3 && (
                <>
                  <span className="text-gray-400">/</span>
                  <span>
                    {parentCategorySlug !== "uncategorized" ? (
                      <Link
                        href={`/${parentCategorySlug}`}
                        className="text-indigo-600 hover:underline transition-colors"
                      >
                        {parentCategoryTitle}
                      </Link>
                    ) : (
                      <span className="text-gray-600">{parentCategoryTitle}</span>
                    )}
                  </span>
                </>
              )}
              <span className="text-gray-400">/</span>
              <span>
                <Link
                  href={
                    slug.length === 3
                      ? `/${categorySlug}/${subCategorySlug}`
                      : `/${categorySlug}`
                  }
                  className="text-indigo-600 hover:underline transition-colors"
                >
                  {categoryTitle}
                </Link>
              </span>
            </div>
          </nav>

          {/* Post Title */}
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-gray-900 mb-6 leading-tight">
            {post.title}
          </h1>

          {/* Meta Description */}
          {post.meta?.description && (
            <p className="text-lg text-gray-700 mb-10 leading-relaxed italic border-l-4 border-indigo-600 pl-4">
              {post.meta.description}
            </p>
          )}

          {/* Hero Image */}
          {post.layout?.[0]?.blockType === "mediaBlock" &&
            post.layout[0].media && (
              <figure className="mb-10">
                <div className="relative">
                  <img
                    src={post.layout[0].media.url}
                    alt={post.layout[0].media.alt || "Hero Image"}
                    className="w-full h-64 sm:h-96 object-cover rounded-lg shadow-lg"
                  />
                  {post.layout[0].media.caption && (
                    <figcaption className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent text-white text-sm p-4 rounded-b-lg">
                      {post.layout[0].media.caption}
                    </figcaption>
                  )}
                </div>
              </figure>
            )}

          {/* Hero Rich Text */}
          {post.hero?.richText?.length > 0 && (
            <section className="prose prose-lg prose-indigo max-w-none mb-12 text-gray-800">
              {post.hero.richText.map((block, index) => (
                <p key={index} className="leading-relaxed">
                  {block.children.map((child, i) => (
                    <span
                      key={i}
                      className={`${child.bold ? "font-semibold" : ""} ${
                        child.italic ? "italic" : ""
                      }`}
                    >
                      {child.text}
                    </span>
                  ))}
                </p>
              ))}
            </section>
          )}

          {/* Post Content */}
          {post.layout?.slice(1).map((block, index) => (
            <section key={index} className="mb-12">
              {block.blockType === "mediaBlock" && block.media && (
                <figure className="my-8">
                  <img
                    src={block.media.url}
                    alt={block.media.alt || "Media"}
                    className="w-full max-w-2xl mx-auto h-auto object-cover rounded-md shadow-md"
                  />
                  {block.media.caption && (
                    <figcaption className="text-sm text-gray-600 mt-3 text-center">
                      {block.media.caption}
                    </figcaption>
                  )}
                </figure>
              )}

              {block.blockType === "content" && block.content && (
                <div
                  className="prose prose-lg prose-gray max-w-none text-gray-800 leading-relaxed"
                  dangerouslySetInnerHTML={{ __html: block.content }}
                />
              )}
            </section>
          ))}

          {/* Tags */}
          {post.tags?.length > 0 && (
            <div className="post-tags mt-8">
              <div className="tags flex flex-wrap gap-2">
                {post.tags.map((tag) => (
                  <Link key={tag.id} href={`/tags/${tag.slug}`}>
                    <span className="inline-block bg-gray-100 rounded-full px-4 py-1.5 text-sm font-medium text-gray-700 hover:bg-indigo-100 hover:text-indigo-700 transition-colors">
                      {tag.title}
                    </span>
                  </Link>
                ))}
              </div>
            </div>
          )}
        </article>

        {/* Sidebar: Latest Posts */}
        <aside className="lg:col-span-1 mt-12 lg:mt-0">
          <div className="sticky top-20 bg-gray-50 border border-gray-200 rounded-lg p-6 shadow-sm">
            <h2
              className="text-xl font-bold text-gray-900 mb-4 pb-2 border-b border-gray-300"
              style={{
                borderLeft: "5px solid #333",
                paddingLeft: "10px",
              }}
            >
              Latest Posts
            </h2>
            {latestPosts.length > 0 ? (
              <div
                className="space-y-4"
                style={{ display: "flex", flexDirection: "column", gap: "16px" }}
              >
                {await Promise.all(
                  latestPosts.map(async (latestPost) => {
                    let latestCategorySlug =
                      latestPost.categories?.[0]?.slug || "uncategorized";
                    let latestParentCategorySlug = "uncategorized";

                    // Fetch parent category slug if it exists
                    if (latestPost.categories?.[0]?.parent) {
                      const parent = latestPost.categories[0].parent;
                      if (typeof parent === "string") {
                        const parentCategory = await fetchParentCategory(parent);
                        if (parentCategory) {
                          latestParentCategorySlug = parentCategory.slug || "uncategorized";
                        }
                      } else {
                        latestParentCategorySlug = parent.slug || "uncategorized";
                      }
                    }

                    // Define imageUrl and imageAlt for each latestPost
                    const imageUrl =
                      latestPost.meta?.image?.url ||
                      latestPost.layout?.find(
                        (block) =>
                          block.blockType === "mediaBlock" && block.media?.url
                      )?.media?.url ||
                      "";
                    const imageAlt =
                      latestPost.meta?.image?.alt ||
                      latestPost.layout?.find(
                        (block) =>
                          block.blockType === "mediaBlock" && block.media?.alt
                      )?.media?.alt ||
                      "Post Image";

                    return (
                      <Link
                        key={latestPost.id}
                        href={
                          latestParentCategorySlug === "uncategorized"
                            ? `/${latestCategorySlug}/${latestPost.slug}`
                            : `/${latestParentCategorySlug}/${latestCategorySlug}/${latestPost.slug}`
                        }
                        className="block p-4 bg-white border border-gray-200 rounded-md hover:shadow-md hover:bg-gray-100 transition-all"
                      >
                        <Card
                          hoverable
                          style={{
                            border: "none",
                            display: "flex",
                            alignItems: "center",
                          }}
                          bodyStyle={{
                            padding: "8px",
                            display: "flex",
                            alignItems: "center",
                          }}
                        >
                          <div style={{ flex: 1 }}>
                            <div
                              style={{
                                ...clampStyle,
                                fontSize: "14px",
                                fontWeight: "bold",
                              }}
                            >
                              {latestPost.title}
                            </div>
                            <div style={{ marginTop: "4px" }}>
                              <Space size={4}>
                                <ClockCircleOutlined
                                  style={{ fontSize: "12px", color: "#8c8c8c" }}
                                />
                                <Text
                                  type="secondary"
                                  style={{ fontSize: "12px" }}
                                >
                                  5 Min Read
                                </Text>
                              </Space>
                            </div>
                          </div>
                          {imageUrl ? (
                            <img
                              alt={imageAlt}
                              src={imageUrl}
                              style={{
                                width: "120px",
                                height: "80px",
                                objectFit: "cover",
                                borderRadius: "4px",
                                marginLeft: "12px",
                              }}
                            />
                          ) : (
                            <div
                              style={{
                                width: "120px",
                                height: "80px",
                                backgroundColor: "#f0f0f0",
                                borderRadius: "4px",
                                marginLeft: "12px",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                              }}
                            >
                              <Text type="secondary" style={{ fontSize: "12px" }}>
                                No Image
                              </Text>
                            </div>
                          )}
                        </Card>
                      </Link>
                    );
                  })
                )}
              </div>
            ) : (
              <p className="text-gray-600">No recent posts available.</p>
            )}
          </div>
        </aside>
      </div>
    </div>
  );
}

// Generate static parameters for Next.js static generation
export async function generateStaticParams() {
  console.log("Entering generateStaticParams for [...slug]");

  try {
    const res = await axios.get(`${apiUrl}/api/posts?limit=1000&depth=2`);
    const data = await res.data;
    console.log(`Fetched ${data.docs.length} posts for static generation`);

    const params = [];
    for (const post of data.docs) {
      const category = post.categories?.[0];
      let categorySlug = category?.slug || "uncategorized";
      let parentCategorySlug = "uncategorized";

      if (category?.parent) {
        const parent = typeof category.parent === "string"
          ? await fetchParentCategory(category.parent)
          : category.parent;
        if (parent) {
          parentCategorySlug = parent.slug || "uncategorized";
          params.push({
            slug: [parentCategorySlug, categorySlug, post.slug],
          });
          console.log(`Generated path for post ${post.slug}: ${parentCategorySlug}/${categorySlug}/${post.slug}`);
        }
      }
      // Always include the 2-segment path for the post
      const twoSegmentPath = [categorySlug, post.slug];
      params.push({
        slug: twoSegmentPath,
      });
      console.log(`Generated path for post ${post.slug}: ${twoSegmentPath.join("/")}`);
    }

    console.log(`Total static params generated: ${params.length}`);
    return params;
  } catch (error) {
    console.error("Error generating static params:", error.response?.data || error.message);
    return [];
  }
}