// src/app/[...slug]/page.tsx

import axios from "axios";
import { notFound } from "next/navigation";
import Link from "next/link";
import { Card, Space } from "antd";
import { ClockCircleOutlined } from "@ant-design/icons";
import Text from "antd/es/typography/Text";

// Type definitions
type RichTextChild = {
  text: string;
  bold?: boolean;
  italic?: boolean;
};

type RichTextBlock = {
  children: RichTextChild[];
};

type LayoutBlock = {
  blockType: string;
  media?: {
    url: string;
    alt?: string;
    width?: number;
    height?: number;
    caption?: string;
  };
  content?: {
    richText?: RichTextBlock[];
  };
};

type Tag = {
  id: string;
  title: string;
  slug: string;
};

type Author = {
  id: string;
  name: string;
  slug: string;
};

type Category = {
  id: string;
  title: string;
  slug: string;
  parent?: { id: string; slug: string; title: string } | string;
};

type Post = {
  id: string;
  title: string;
  slug: string;
  publishedAt: string;
  layout?: LayoutBlock[];
  hero?: {
    type: string;
    richText?: RichTextBlock[];
    links?: any[];
  };
  meta?: {
    description?: string;
    image?: {
      url: string;
      alt?: string;
    };
  };
  categories?: Category[];
  populatedAuthors?: Author[];
  tags?: Tag[];
};

// API base URL
const apiUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:3000";

// Fetch a post by slug
async function fetchPostBySlug(slug: string): Promise<Post | null> {
  try {
    const response = await axios.get(
      `${apiUrl}/api/posts?where[slug][equals]=${slug}&depth=2`
    );
    const post = response.data.docs[0] || null;
    if (!post) {
      console.log(`No post found for slug: ${slug}`);
    } else {
      console.log(`Fetched post with slug ${slug}:`, post);
    }
    return post;
  } catch (error) {
    console.error(
      `Error fetching post with slug ${slug}:`,
      error.response?.data || error.message
    );
    return null;
  }
}

// Fetch parent category details by ID
async function fetchParentCategory(
  parentId: string
): Promise<{ slug: string; title: string } | null> {
  try {
    const res = await axios.get(`${apiUrl}/api/categories/${parentId}?depth=1`);
    const parentCategory = res.data || null;
    if (!parentCategory) {
      console.log(`No parent category found for ID: ${parentId}`);
      return null;
    }
    console.log(`Fetched parent category for ID ${parentId}:`, parentCategory);
    return {
      slug: parentCategory.slug || "uncategorized",
      title: parentCategory.title || "Uncategorized",
    };
  } catch (err) {
    console.error(
      `Error fetching parent category with ID ${parentId}:`,
      err.response?.data || err.message
    );
    return null;
  }
}

// Render rich text content
function renderRichText(richText: RichTextBlock[] | undefined) {
  if (!richText) return null;
  return richText.map((block, index) => (
    <p key={index}>
      {block.children.map((child, childIndex) => {
        let text = <span key={childIndex}>{child.text}</span>;
        if (child.bold) text = <strong>{text}</strong>;
        if (child.italic) text = <em>{text}</em>;
        return text;
      })}
    </p>
  ));
}

// Main PostPage component
export default async function PostPage({
  params,
}: {
  params: Promise<{ slug: string[] }>;
}) {
  // Await params to resolve the Promise
  const { slug } = await params;
  console.log(`Handling post page for slug: ${slug.join("/")}`);

  // Validate slug length
  if (slug.length !== 2 && slug.length !== 3) {
    console.log(`Invalid slug length: ${slug.length} for slug: ${slug.join("/")}`);
    notFound();
  }

  // Extract the post slug (last part of the URL)
  const postSlug = slug[slug.length - 1];
  console.log(`Fetching post with slug: ${postSlug}`);

  // Fetch the post
  const post = await fetchPostBySlug(postSlug);
  if (!post) {
    console.log(`Post not found for slug: ${postSlug}`);
    notFound();
  }

  // Determine the category structure
  let categorySlug = "";
  let subCategorySlug = "";
  let parentCategorySlug = "";
  let parentCategoryTitle = "";
  let subCategoryTitle = "";

  if (slug.length === 2) {
    // Top-level category: e.g., /cinema/post-slug
    categorySlug = slug[0];
    const postCategories = post.categories || [];
    const categoryMatch = postCategories.some((cat) => cat.slug === categorySlug && !cat.parent);
    if (!categoryMatch) {
      console.log(
        `Post ${postSlug} does not belong to top-level category ${categorySlug}`
      );
      notFound();
    }
    parentCategorySlug = categorySlug;
    parentCategoryTitle = postCategories.find((cat) => cat.slug === categorySlug)?.title || categorySlug;
  } else if (slug.length === 3) {
    // Subcategory: e.g., /news/tamilnadu/post-slug
    categorySlug = slug[0];
    subCategorySlug = slug[1];
    const postCategories = post.categories || [];
    const subCategoryMatch = postCategories.find((cat) => cat.slug === subCategorySlug);
    if (!subCategoryMatch) {
      console.log(
        `Post ${postSlug} does not belong to subcategory ${subCategorySlug}`
      );
      notFound();
    }

    const parent = typeof subCategoryMatch.parent === "string"
      ? await fetchParentCategory(subCategoryMatch.parent)
      : subCategoryMatch.parent;

    if (!parent || parent.slug !== categorySlug) {
      console.log(
        `Post ${postSlug} subcategory ${subCategorySlug} does not belong under parent category ${categorySlug}`
      );
      notFound();
    }

    parentCategorySlug = parent.slug;
    parentCategoryTitle = parent.title;
    subCategoryTitle = subCategoryMatch.title;
  }

  // Extract image for the post
  const imageUrl =
    post.meta?.image?.url ||
    post.layout?.find(
      (block) => block.blockType === "mediaBlock" && block.media?.url
    )?.media?.url ||
    "";
  const imageAlt =
    post.meta?.image?.alt ||
    post.layout?.find(
      (block) => block.blockType === "mediaBlock" && block.media?.alt
    )?.media?.alt ||
    "Post Image";

  return (
    <div
      className="container mx-auto px-4 sm:px-6 lg:px-8 py-12"
      style={{ maxWidth: "1200px", margin: "0px auto", padding: "0px 16px" }}
    >
      {/* Breadcrumbs */}
      <nav
        aria-label="Breadcrumb"
        className="mb-6 text-sm font-medium text-gray-600"
      >
        <div className="flex items-center space-x-2 breadcrumbs">
          <span>
            <Link
              href="/"
              className="text-indigo-600 hover:underline transition-colors"
            >
              Home
            </Link>
          </span>
          <span className="text-gray-400">/</span>
          <span>
            <Link
              href={`/${parentCategorySlug}`}
              className="text-indigo-600 hover:underline transition-colors"
            >
              {parentCategoryTitle}
            </Link>
          </span>
          {slug.length === 3 && (
            <>
              <span className="text-gray-400">/</span>
              <span>
                <Link
                  href={`/${parentCategorySlug}/${subCategorySlug}`}
                  className="text-indigo-600 hover:underline transition-colors"
                >
                  {subCategoryTitle}
                </Link>
              </span>
            </>
          )}
          <span className="text-gray-400">/</span>
          <span className="text-gray-600">{post.title}</span>
        </div>
      </nav>

      {/* Post Title */}
      <h1 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
        {post.title}
      </h1>

      {/* Post Meta */}
      <div className="mb-6">
        <Space size={4}>
          <ClockCircleOutlined style={{ fontSize: "12px", color: "#8c8c8c" }} />
          <Text type="secondary" style={{ fontSize: "12px" }}>
            {new Date(post.publishedAt).toLocaleDateString()} • 5 Min Read
          </Text>
        </Space>
      </div>

      {/* Post Image */}
      {imageUrl && (
        <div className="mb-6">
          <img
            src={imageUrl}
            alt={imageAlt}
            className="w-full h-auto max-h-96 object-cover rounded-md"
          />
        </div>
      )}

      {/* Post Content */}
      <div className="prose max-w-none">
        {post.hero?.richText && renderRichText(post.hero.richText)}
        {post.layout?.map((block, index) => {
          if (block.blockType === "content") {
            return (
              <div key={index}>
                {block.content?.richText && renderRichText(block.content.richText)}
              </div>
            );
          }
          if (block.blockType === "mediaBlock" && block.media?.url) {
            return (
              <div key={index} className="my-4">
                <img
                  src={block.media.url}
                  alt={block.media.alt || "Media"}
                  className="w-full h-auto max-h-96 object-cover rounded-md"
                />
                {block.media.caption && (
                  <p className="text-sm text-gray-600 mt-2">{block.media.caption}</p>
                )}
              </div>
            );
          }
          return null;
        })}
      </div>

      {/* Tags */}
      {post.tags && post.tags.length > 0 && (
        <div className="mt-6">
          <Text strong>Tags: </Text>
          <Space wrap>
            {post.tags.map((tag) => (
              <Link
                key={tag.id}
                href={`/tags/${tag.slug}`}
                className="text-indigo-600 hover:underline"
              >
                {tag.title}
              </Link>
            ))}
          </Space>
        </div>
      )}

      {/* Authors */}
      {post.populatedAuthors && post.populatedAuthors.length > 0 && (
        <div className="mt-6">
          <Text strong>Author{post.populatedAuthors.length > 1 ? "s" : ""}: </Text>
          <Space wrap>
            {post.populatedAuthors.map((author) => (
              <Link
                key={author.id}
                href={`/authors/${author.slug}`}
                className="text-indigo-600 hover:underline"
              >
                {author.name}
              </Link>
            ))}
          </Space>
        </div>
      )}
    </div>
  );
}

// Generate static parameters for Next.js static generation
export async function generateStaticParams() {
  try {
    const res = await axios.get(`${apiUrl}/api/posts?limit=100&depth=2`);
    const posts = res.data.docs || [];
    console.log(`Fetched ${posts.length} posts for static generation`);

    const params = [];
    for (const post of posts) {
      const categories = post.categories || [];
      for (const category of categories) {
        const parent = typeof category.parent === "string"
          ? await fetchParentCategory(category.parent)
          : category.parent;
        if (parent) {
          // Subcategory post: e.g., /news/tamilnadu/post-slug
          params.push({
            slug: [parent.slug, category.slug, post.slug],
          });
          console.log(
            `Generated path for post ${post.slug}: ${parent.slug}/${category.slug}/${post.slug}`
          );
        } else {
          // Top-level category post: e.g., /cinema/post-slug
          params.push({
            slug: [category.slug, post.slug],
          });
          console.log(
            `Generated path for post ${post.slug}: ${category.slug}/${post.slug}`
          );
        }
      }
    }

    console.log(`Total static params generated: ${params.length}`);
    return params;
  } catch (error) {
    console.error(
      "Error generating static params for posts:",
      error.response?.data || error.message
    );
    return [];
  }
}