export async function getPosts() {
    const res = await fetch('http://localhost:3000/api/posts?limit=10');
    if (!res.ok) throw new Error('Failed to fetch posts');
    return res.json();
  }
  
  export async function getPostBySlug(slug: string) {
    const res = await fetch(`http://localhost:3000/api/posts?where[slug][equals]=${slug}`);
    if (!res.ok) throw new Error('Failed to fetch post');
    const data = await res.json();
    return data.docs[0];
  }
  