import axios from 'axios';
import Link from 'next/link';

type Category = {
  id: string;
  title: string;
  slug: string;
  parent?: { id: string; slug: string; title: string } | string;
};

type Post = {
  id: string;
  title: string;
  slug: string;
  publishedAt: string;
  meta?: {
    description?: string;
  };
  tags?: { id: string; title: string; slug: string }[];
  layout?: {
    blockType: string;
    media?: {
      url: string;
      alt?: string;
    };
  }[];
};

const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000';

// Cache for categories to avoid repeated API calls
const categoryCache = new Map<string, Category>();

async function fetchCategoryBySlug(slug: string): Promise<Category | null> {
  // Check cache first
  if (categoryCache.has(slug)) {
    return categoryCache.get(slug)!;
  }

  try {
    const res = await axios.get(`${apiUrl}/api/categories?where[slug][equals]=${slug}&depth=2`);
    const category = res.data.docs[0] || null;
    if (!category) {
      console.log(`No category found for slug: ${slug}`);
      return null;
    }

    categoryCache.set(slug, category);
    return category;
  } catch (err) {
    console.error(`Error fetching category with slug ${slug}:`, err.response?.data || err.message);
    return null;
  }
}

async function fetchSubcategories(parentId: string): Promise<Category[]> {
  try {
    const res = await axios.get(
      `${apiUrl}/api/categories?where[parent][equals]=${parentId}&depth=2`
    );
    const subcategories = res.data.docs || [];
    console.log(`Fetched ${subcategories.length} subcategories for parent ID ${parentId}`);
    return subcategories;
  } catch (err) {
    console.error(`Error fetching subcategories for parent ID ${parentId}:`, err.response?.data || err.message);
    return [];
  }
}

async function fetchPostsByCategory(categoryId: string, limit: number = 5): Promise<Post[]> {
  try {
    const res = await axios.get(
      `${apiUrl}/api/posts?limit=${limit}&depth=2&where[categories][contains]=${categoryId}`
    );
    console.log(`Fetched ${res.data.docs.length} posts for category ID ${categoryId}`);
    return res.data.docs || [];
  } catch (err) {
    console.error(`Error fetching posts for category ID ${categoryId}:`, err.response?.data || err.message);
    return [];
  }
}

async function fetchAllCategories(): Promise<Category[]> {
  try {
    const res = await axios.get(`${apiUrl}/api/categories?depth=2`);
    const categories = res.data.docs || [];
    console.log('Fetched all categories:', categories);
    // Cache all categories
    categories.forEach((category: Category) => {
      if (category.slug) {
        categoryCache.set(category.slug, category);
      }
    });
    return categories;
  } catch (err) {
    console.error('Error fetching all categories:', err.response?.data || err.message);
    return [];
  }
}

export default async function CategoryPage({
  params,
}: {
  params: { categorySlug: string };
}) {
  const category = await fetchCategoryBySlug(params.categorySlug);

  if (!category) {
    return (
      <div className="container mx-auto px-4 py-12 text-center text-gray-500">
        Category not found
      </div>
    );
  }

  // Check if this category has subcategories (i.e., it's a parent category)
  const subcategories = await fetchSubcategories(category.id);

  if (subcategories.length > 0) {
    // This is a parent category (e.g., /news), show subcategories
    return (
      <div className="container mx-auto px-4 py-12">
        {/* Breadcrumbs */}
        <nav className="text-sm text-gray-600 mb-6">
          <ol className="flex items-center space-x-2" style={{ display: 'flex', gap: '20px', listStyleType: 'none' }}>
            <li>
              <Link href="/" className="text-indigo-600 hover:underline">
                Home
              </Link>
            </li>
            <li className="text-gray-400"> > </li>
            <li>
              <span className="text-gray-800">{category.title}</span>
            </li>
          </ol>
        </nav>

        <h1 className="text-3xl font-bold mb-8 capitalize">{category.title}</h1>

        {subcategories.length === 0 ? (
          <p className="text-gray-500">No subcategories found.</p>
        ) : (
          await Promise.all(
            subcategories.map(async (subcategory) => {
              const posts = await fetchPostsByCategory(subcategory.id);
              if (posts.length === 0) return null;

              return (
                <section key={subcategory.slug} className="mb-10">
                  <Link href={`/${params.categorySlug}/${subcategory.slug}`}>
                    <h2 className="text-2xl font-bold mb-4 capitalize hover:text-indigo-600 transition">
                      {subcategory.title}
                    </h2>
                  </Link>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {posts.map((post) => {
                      const mediaBlock = post.layout?.find(
                        (block) => block.blockType === 'mediaBlock'
                      );
                      const imageUrl = mediaBlock?.media?.url;
                      const imageAlt = mediaBlock?.media?.alt || post.title;

                      return (
                        <Link
                          key={post.id}
                          href={`/${params.categorySlug}/${subcategory.slug}/${post.slug}`}
                          className="border rounded-lg overflow-hidden hover:shadow-lg transition"
                        >
                          {imageUrl && (
                            <img
                              src={imageUrl}
                              alt={imageAlt}
                              className="w-full h-48 object-cover"
                            />
                          )}
                          <div className="p-4">
                            <h3 className="text-lg font-semibold mb-1">{post.title}</h3>
                            <p className="text-sm text-gray-500">
                              {new Date(post.publishedAt).toLocaleDateString('en-US', {
                                day: 'numeric',
                                month: 'short',
                                year: 'numeric',
                              })}
                            </p>
                          </div>
                        </Link>
                      );
                    })}
                  </div>
                </section>
              );
            })
          )
        )}
      </div>
    );
  }

  // If no subcategories, this is a standalone category with no parent (e.g., /lifestyle)
  const posts = await fetchPostsByCategory(category.id, 10);

  return (
    <div className="container mx-auto px-4 py-12">
      {/* Breadcrumbs */}
      <nav className="text-sm text-gray-600 mb-6">
        <ol className="flex items-center space-x-2" style={{ display: 'flex', gap: '20px', listStyleType: 'none' }}>
          <li>
            <Link href="/" className="text-indigo-600 hover:underline">
              Home
            </Link>
          </li>
          <li className="text-gray-400"> > </li>
          <li>
            <span className="text-gray-800">{category.title}</span>
          </li>
        </ol>
      </nav>

      <h1 className="text-3xl font-bold mb-8 capitalize">{category.title}</h1>

      {posts.length === 0 ? (
        <p className="text-gray-500">No posts found in this category.</p>
      ) : (
        <div className="space-y-8">
          {posts.map((post) => {
            const mediaBlock = post.layout?.find(
              (block) => block.blockType === 'mediaBlock'
            );
            const imageUrl = mediaBlock?.media?.url;
            const imageAlt = mediaBlock?.media?.alt || post.title;

            return (
              <Link
                key={post.id}
                href={`/${params.categorySlug}/${post.slug}`}
                className="flex flex-col md:flex-row gap-4 border-b pb-6 hover:bg-gray-50 transition"
              >
                {imageUrl && (
                  <div className="md:w-1/4">
                    <img
                      src={imageUrl}
                      alt={imageAlt}
                      className="rounded-lg w-full h-32 object-cover"
                    />
                  </div>
                )}
                <div className="flex-1">
                  <h2 className="text-xl font-semibold mb-2">{post.title}</h2>
                  {post.meta?.description && (
                    <p className="text-gray-600 mb-2 line-clamp-2">
                      {post.meta.description}
                    </p>
                  )}
                  {post.tags?.length > 0 && (
                    <div className="text-sm text-gray-600">
                      <Link href={`/tags/${post.tags[0].slug}`}>
                        <span className="inline-block text-indigo-600 mr-2 hover:underline">
                          #{post.tags[0].title}
                        </span>
                      </Link>
                    </div>
                  )}
                </div>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}

export async function generateStaticParams() {
  const categories = await fetchAllCategories();
  const params = [];

  for (const category of categories) {
    if (!category.slug || typeof category.slug !== 'string') {
      console.warn(`Skipping category with invalid slug:`, category);
      continue;
    }

    params.push({
      categorySlug: category.slug,
    });
  }

  // Add the 'uncategorized' category
  params.push({
    categorySlug: 'uncategorized',
  });

  return params;
}