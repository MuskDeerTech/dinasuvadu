import axios from 'axios';
import Link from 'next/link';

type Tag = {
  id: string;
  title: string;
  slug: string;
};

type Category = {
  id: string;
  slug: string;
  title?: string;
  parent?: { id: string; slug: string; title: string } | string;
};

type Post = {
  id: string;
  title: string;
  slug: string;
  publishedAt: string;
  meta?: {
    description?: string;
  };
  tags?: { id: string; title: string; slug: string }[];
  layout?: {
    blockType: string;
    media?: {
      url: string;
      alt?: string;
    };
  }[];
  categories?: Category[];
};

const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000';

async function fetchTags(): Promise<Tag[]> {
  try {
    const res = await axios.get(`${apiUrl}/api/tags?depth=1`);
    const tags = res.data.docs || [];
    console.log('Fetched tags:', tags);
    return tags;
  } catch (err) {
    console.error('Error fetching tags:', err.response?.data || err.message);
    return [];
  }
}

async function fetchTagBySlug(slug: string): Promise<Tag | null> {
  try {
    const res = await axios.get(`${apiUrl}/api/tags?where[slug][equals]=${slug}&depth=1`);
    const tag = res.data.docs[0] || null;
    if (!tag) {
      console.log(`No tag found for slug: ${slug}`);
    }
    return tag;
  } catch (err) {
    console.error(`Error fetching tag with slug ${slug}:`, err.response?.data || err.message);
    return null;
  }
}

async function fetchPostsByTag(tagId: string): Promise<Post[]> {
  try {
    const res = await axios.get(
      `${apiUrl}/api/posts?limit=10&depth=3&where[tags][contains]=${tagId}`
    );
    console.log(`Fetched ${res.data.docs.length} posts for tag ID ${tagId}`);
    return res.data.docs || [];
  } catch (err) {
    console.error(`Error fetching posts for tag ID ${tagId}:`, err.response?.data || err.message);
    return [];
  }
}

async function fetchParentCategory(parentId: string): Promise<{ slug: string; title: string } | null> {
  try {
    const res = await axios.get(`${apiUrl}/api/categories/${parentId}?depth=1`);
    const parentCategory = res.data || null;
    if (!parentCategory) {
      console.log(`No parent category found for ID: ${parentId}`);
      return null;
    }
    return {
      slug: parentCategory.slug || 'uncategorized',
      title: parentCategory.title || 'Uncategorized',
    };
  } catch (err) {
    console.error(`Error fetching parent category with ID ${parentId}:`, err.response?.data || err.message);
    return null;
  }
}

export default async function TagPage({
  params,
}: {
  params: { tagSlug: string };
}) {
  const tag = await fetchTagBySlug(params.tagSlug);

  if (!tag) {
    return (
      <div className="container mx-auto px-4 py-12 text-center text-gray-500">
        Tag not found
      </div>
    );
  }

  const posts = await fetchPostsByTag(tag.id);

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold mb-8 capitalize">{tag.title}</h1>

      {posts.length === 0 ? (
        <p className="text-gray-500">No posts found for this tag.</p>
      ) : (
        <div className="space-y-8">
          {await Promise.all(
            posts.map(async (post) => {
              const mediaBlock = post.layout?.find(
                (block) => block.blockType === 'mediaBlock'
              );
              const imageUrl = mediaBlock?.media?.url;
              const imageAlt = mediaBlock?.media?.alt || post.title;

              const category = post.categories?.[0];
              let parentCategorySlug = 'uncategorized';
              let parentCategoryTitle = 'Uncategorized';
              const categorySlug = category?.slug || 'uncategorized';
              const categoryTitle = category?.title || 'Uncategorized';

              if (category?.parent) {
                const parent = typeof category.parent === 'string'
                  ? await fetchParentCategory(category.parent)
                  : category.parent;
                if (parent) {
                  parentCategorySlug = parent.slug || 'uncategorized';
                  parentCategoryTitle = parent.title || 'Uncategorized';
                }
              }

              return (
                <Link
                  key={post.id}
                  href={`/${parentCategorySlug}/${categorySlug}/${post.slug}`}
                  className="flex flex-col md:flex-row gap-4 border-b pb-6 hover:bg-gray-50 transition"
                >
                  {imageUrl && (
                    <div className="md:w-1/4">
                      <img
                        src={imageUrl}
                        alt={imageAlt}
                        className="rounded-lg w-full h-32 object-cover"
                      />
                    </div>
                  )}
                  <div className="flex-1">
                    <div className="text-sm text-indigo-600 mb-1">
                      <Link href={`/${parentCategorySlug}/${categorySlug}`} className="hover:underline">
                        {parentCategoryTitle} > {categoryTitle}
                      </Link>
                    </div>
                    <h2 className="text-xl font-semibold mb-2">{post.title}</h2>
                    {post.meta?.description && (
                      <p className="text-gray-600 mb-2 line-clamp-2">
                        {post.meta.description}
                      </p>
                    )}
                    <div className="text-sm text-gray-500 mb-2">
                      {new Date(post.publishedAt).toLocaleDateString('en-US', {
                        day: 'numeric',
                        month: 'short',
                        year: 'numeric',
                      })}
                    </div>
                    {post.tags?.length > 0 && (
                      <div className="text-sm text-gray-600">
                        <Link href={`/tags/${post.tags[0].slug}`}>
                          <span className="inline-block text-indigo-600 mr-2 hover:underline">
                            #{post.tags[0].title}
                          </span>
                        </Link>
                      </div>
                    )}
                  </div>
                </Link>
              );
            })
          )}
        </div>
      )}
    </div>
  );
}

export async function generateStaticParams() {
  const tags = await fetchTags();
  const validTags = tags.filter((tag: Tag) => {
    if (!tag.slug || typeof tag.slug !== 'string') {
      console.warn(`Skipping tag with invalid slug:`, tag);
      return false;
    }
    return true;
  });

  return validTags.map((tag: Tag) => ({
    tagSlug: tag.slug,
  }));
}