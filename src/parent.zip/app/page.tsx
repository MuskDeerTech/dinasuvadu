import axios from 'axios';
import Link from 'next/link';
import { Row, Col, Card, Typography, Space } from 'antd';
import { ClockCircleOutlined } from '@ant-design/icons';

import Title from 'antd/es/typography/Title';
import Text from 'antd/es/typography/Text';

// Type definitions
type Category = {
  id: string;
  title: string;
  slug: string;
  parent?: { id: string; slug: string; title: string } | string;
};

type Post = {
  id: string;
  title: string;
  slug: string;
  publishedAt: string;
  author?: string;
  categories?: Category[];
  layout?: {
    blockType: string;
    media?: {
      url: string;
      alt?: string;
    };
  }[];
};

const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000';

// Fetch categories
async function fetchCategories(): Promise<Category[]> {
  try {
    const res = await axios.get(`${apiUrl}/api/categories?depth=2`);
    const categories = res.data.docs || [];
    console.log('Fetched categories:', categories);
    return categories;
  } catch (err) {
    console.error('Error fetching categories:', err.response?.data || err.message);
    return [];
  }
}

// Fetch latest posts (for the "Latest News" section)
async function fetchLatestPosts(): Promise<Post[]> {
  try {
    const res = await axios.get(`${apiUrl}/api/posts?limit=4&depth=2&sort=-publishedAt`);
    const posts = res.data.docs || [];
    console.log(`Fetched ${posts.length} latest posts`);
    console.log('Latest posts:', posts);
    return posts;
  } catch (err) {
    console.error('Error fetching latest posts:', err.response?.data || err.message);
    return [];
  }
}

// Fetch posts by category
async function fetchPostsByCategory(categoryId: string): Promise<Post[]> {
  try {
    const res = await axios.get(
      `${apiUrl}/api/posts?limit=7&depth=2&where[categories][contains]=${categoryId}`
    );
    console.log(`Fetched ${res.data.docs.length} posts for category ID ${categoryId}`);
    return res.data.docs || [];
  } catch (err) {
    console.error(`Error fetching posts for category ID ${categoryId}:`, err.response?.data || err.message);
    return [];
  }
}

// Fetch parent category details by ID
async function fetchParentCategory(
  parentId: string
): Promise<{ slug: string; title: string } | null> {
  try {
    const res = await axios.get(`${apiUrl}/api/categories/${parentId}?depth=1`);
    const parentCategory = res.data || null;
    if (!parentCategory) {
      console.log(`No parent category found for ID: ${parentId}`);
      return null;
    }
    console.log(`Fetched parent category for ID ${parentId}:`, parentCategory);
    return {
      slug: parentCategory.slug || "uncategorized",
      title: parentCategory.title || "Uncategorized",
    };
  } catch (err) {
    console.error(
      `Error fetching parent category with ID ${parentId}:`,
      err.response?.data || err.message
    );
    return null;
  }
}

// Define the clamping style as a reusable CSS object
const clampStyle = {
  display: '-webkit-box',
  WebkitLineClamp: 3,
  WebkitBoxOrient: 'vertical',
  overflow: 'hidden',
  textOverflow: 'ellipsis',
  lineHeight: '1.4',
};

// Helper function to get the URL path for a post
async function getPostUrl(post: Post): Promise<string> {
  if (!post.categories || post.categories.length === 0) {
    // Fallback to a default category that matches your site structure
    return `/uncategorized/${post.slug || 'fallback-slug'}`;
  }

  const primaryCategory = post.categories[0]; // Use the first category

  // Check if the category has a parent
  if (primaryCategory.parent) {
    let parentCategorySlug = "uncategorized";
    const parent = typeof primaryCategory.parent === "string"
      ? await fetchParentCategory(primaryCategory.parent) // Fetch parent if it's an ID
      : primaryCategory.parent;

    if (parent) {
      parentCategorySlug = parent.slug || "uncategorized";
      return `/${parentCategorySlug}/${primaryCategory.slug}/${post.slug || 'fallback-slug'}`;
    }
  }

  // If no parent category (or parent fetch failed), exclude the parent category slug
  return `/${primaryCategory.slug}/${post.slug || 'fallback-slug'}`;
}

export default async function Home() {
  const categories = await fetchCategories();
  const latestPosts = await fetchLatestPosts();

  // Split the latest posts: 1 for featured, 3 for the second column
  const featuredPost = latestPosts.length > 0 ? latestPosts[0] : null;
  const smallerPosts = latestPosts.length > 1 ? latestPosts.slice(1, 4) : []; // 3 smaller posts

  // Define the desired order of specific categories
  const categoryOrder: { [key: string]: number } = {
    தமிழ்நாடு: 0, // First
    இந்தியா: 1,   // Second
    உலகம்: 2,    // Third
  };

  // Sort categories: Prioritize தமிழ்நாடு, இந்தியா, உலகம், then reverse the rest
  const sortedCategories = [...categories].sort((a, b) => {
    const orderA = categoryOrder[a.title] ?? 999;
    const orderB = categoryOrder[b.title] ?? 999;

    if (orderA !== 999 && orderB !== 999) {
      return orderA - orderB;
    }
    if (orderA !== 999) {
      return -1;
    }
    if (orderB !== 999) {
      return 1;
    }
    return categories.indexOf(b) - categories.indexOf(a);
  });

  console.log('Sorted categories:', sortedCategories.map(cat => cat.title));

  return (
    <div style={{ padding: '24px', maxWidth: '1200px', margin: '0 auto' }}>
      {/* Latest News Section (2 Columns: 1 Featured, 3 Smaller Posts) */}
      {(featuredPost || smallerPosts.length > 0) && (
        <section style={{ marginBottom: '40px' }}>
          <Title level={2} style={{ color: '#194277', borderLeft: '5px solid #333', paddingLeft: '10px', paddingBottom: '8px' }}>
            தற்போதைய செய்திகள் (Latest News)
          </Title>
          <Row gutter={[16, 16]}>
            {/* First Column: Featured Post (60%) */}
            {featuredPost && (
              <Col xs={24} md={14}>
                <Link href={await getPostUrl(featuredPost)}>
                  <Card
                    hoverable
                    style={{
                      borderRadius: '8px',
                      boxShadow: '0 2px 8px rgba(0, 0, 0, 0.15)',
                      border: 'none',
                      position: 'relative',
                      overflow: 'hidden',
                    }}
                    bodyStyle={{ padding: 0 }}
                  >
                    <div style={{ position: 'relative' }}>
                      {featuredPost.layout?.find((block) => block.blockType === 'mediaBlock')?.media?.url ? (
                        <img
                          alt={
                            featuredPost.layout?.find((block) => block.blockType === 'mediaBlock')?.media?.alt ||
                            featuredPost.title
                          }
                          src={featuredPost.layout?.find((block) => block.blockType === 'mediaBlock')?.media?.url}
                          style={{
                            width: '100%',
                            height: '300px',
                            objectFit: 'cover',
                            borderRadius: '8px 8px 0 0',
                            position: 'relative',
                            zIndex: 1,
                          }}
                        />
                      ) : (
                        <div
                          style={{
                            width: '100%',
                            height: '300px',
                            backgroundColor: '#f0f0f0',
                            borderRadius: '8px 8px 0 0',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                          }}
                        >
                          <Text type="secondary">No Image</Text>
                        </div>
                      )}
                      <div
                        style={{
                          position: 'absolute',
                          bottom: 0,
                          left: 0,
                          right: 0,
                          height: '70%',
                          background: 'linear-gradient(to top, rgba(0, 0, 0, 0.9), transparent)',
                          zIndex: 2,
                        }}
                      />
                      <div
                        style={{
                          position: 'absolute',
                          bottom: '16px',
                          left: '16px',
                          right: '16px',
                          color: '#fff',
                          zIndex: 3,
                        }}
                      >
                        <div style={{ ...clampStyle, fontSize: '20px', fontWeight: 'bold' }}>
                          {featuredPost.title}
                        </div>
                        <div style={{ marginTop: '8px' }}>
                          <Text style={{ fontSize: '12px', color: '#e6e6e6' }}>
                            {new Date(featuredPost.publishedAt).toLocaleDateString('en-US', {
                              day: 'numeric',
                              month: 'short',
                              year: 'numeric',
                            })}
                          </Text>
                        </div>
                      </div>
                    </div>
                  </Card>
                </Link>
              </Col>
            )}

            {/* Second Column: 3 Smaller Posts (40%) */}
            <Col xs={24} md={10}>
              <Row gutter={[16, 8]}>
                {await Promise.all(
                  smallerPosts.map(async (post) => {
                    const mediaBlock = post.layout?.find((block) => block.blockType === 'mediaBlock');
                    const imageUrl = mediaBlock?.media?.url;
                    const imageAlt = mediaBlock?.media?.alt || post.title;

                    return (
                      <Col xs={24} key={post.id}>
                        <Link href={await getPostUrl(post)}>
                          <Card
                            hoverable
                            style={{
                              borderRadius: '8px',
                              boxShadow: '0 2px 8px rgba(0, 0, 0, 0.15)',
                              border: 'none',
                              display: 'flex',
                              alignItems: 'center',
                            }}
                            bodyStyle={{ padding: '8px', display: 'flex', alignItems: 'center' }}
                          >
                            <div style={{ flex: 1 }}>
                              <div style={{ ...clampStyle, fontSize: '14px', fontWeight: 'bold' }}>
                                {post.title}
                              </div>
                              <div style={{ marginTop: '4px' }}>
                                <Space size={4}>
                                  <Text type="secondary" style={{ fontSize: '12px' }}>
                                    {new Date(post.publishedAt).toLocaleDateString('en-US', {
                                      day: 'numeric',
                                      month: 'short',
                                      year: 'numeric',
                                    })}
                                  </Text>
                                  <ClockCircleOutlined style={{ fontSize: '12px', color: '#8c8c8c' }} />
                                  <Text type="secondary" style={{ fontSize: '12px' }}>
                                    5 Min Read
                                  </Text>
                                </Space>
                              </div>
                            </div>
                            {imageUrl ? (
                              <img
                                alt={imageAlt}
                                src={imageUrl}
                                style={{
                                  width: '120px',
                                  height: '80px',
                                  objectFit: 'cover',
                                  borderRadius: '4px',
                                  marginLeft: '12px',
                                }}
                              />
                            ) : (
                              <div
                                style={{
                                  width: '120px',
                                  height: '80px',
                                  backgroundColor: '#f0f0f0',
                                  borderRadius: '4px',
                                  marginLeft: '12px',
                                  display: 'flex',
                                  alignItems: 'center',
                                  justifyContent: 'center',
                                }}
                              >
                                <Text type="secondary" style={{ fontSize: '12px' }}>
                                  No Image
                                </Text>
                              </div>
                            )}
                          </Card>
                        </Link>
                      </Col>
                    );
                  })
                )}
              </Row>
            </Col>
          </Row>
        </section>
      )}

      {/* Category-Based Sections (3 Columns: 1 Featured, 3 Smaller Posts, 3 Smaller Posts) */}
      {sortedCategories.length === 0 ? (
        <Text>No categories found.</Text>
      ) : (
        await Promise.all(
          sortedCategories.map(async (category) => {
            const posts = await fetchPostsByCategory(category.id);
            if (posts.length === 0) return null;

            const categoryFeaturedPost = posts.length > 0 ? posts[0] : null;
            const categorySmallerPosts1 = posts.length > 1 ? posts.slice(1, 4) : [];
            const categorySmallerPosts2 = posts.length > 4 ? posts.slice(4, 7) : [];

            if (!categoryFeaturedPost && categorySmallerPosts1.length === 0 && categorySmallerPosts2.length === 0)
              return null;

            // Determine the category link and post base URL based on whether it has a parent
            let categoryLink = `/${category.slug}`;
            let postBaseUrl = `/${category.slug}`;
            if (category.parent) {
              const parent = typeof category.parent === "string"
                ? await fetchParentCategory(category.parent)
                : category.parent;
              if (parent) {
                const parentCategorySlug = parent.slug || 'uncategorized';
                categoryLink = `/${parentCategorySlug}/${category.slug}`;
                postBaseUrl = `/${parentCategorySlug}/${category.slug}`;
              }
            }

            return (
              <section key={category.slug} style={{ marginBottom: '40px' }}>
                <Link href={categoryLink}>
                  <Title
                    level={3}
                    style={{
                      color: '#194277',
                      borderLeft: '5px solid #333',
                      paddingLeft: '10px',
                      paddingBottom: '8px',
                      display: 'inline-block',
                    }}
                  >
                    {category.title}
                  </Title>
                </Link>
                <Row gutter={[16, 16]}>
                  {categoryFeaturedPost && (
                    <Col xs={24} md={8}>
                      <Link href={`${postBaseUrl}/${categoryFeaturedPost.slug}`}>
                        <Card
                          hoverable
                          cover={
                            categoryFeaturedPost.layout?.find((block) => block.blockType === 'mediaBlock')?.media
                              ?.url ? (
                              <img
                                alt={
                                  categoryFeaturedPost.layout?.find((block) => block.blockType === 'mediaBlock')
                                    ?.media?.alt || categoryFeaturedPost.title
                                }
                                src={
                                  categoryFeaturedPost.layout?.find((block) => block.blockType === 'mediaBlock')
                                    ?.media?.url
                                }
                                style={{ height: '184px', objectFit: 'cover', borderRadius: '8px 8px 0 0' }}
                              />
                            ) : (
                              <div
                                style={{
                                  height: '184px',
                                  backgroundColor: '#f0f0f0',
                                  borderRadius: '8px 8px 0 0',
                                  display: 'flex',
                                  alignItems: 'center',
                                  justifyContent: 'center',
                                }}
                              >
                                <Text type="secondary">No Image</Text>
                              </div>
                            )
                          }
                          style={{ borderRadius: '8px', boxShadow: '0 2px 8px rgba(0, 0, 0, 0.15)', border: 'none' }}
                          bodyStyle={{ padding: '12px' }}
                        >
                          <div>
                            <div style={{ ...clampStyle, fontSize: '18px', fontWeight: 'bold' }}>
                              {categoryFeaturedPost.title}
                            </div>
                            <div style={{ marginTop: '8px' }}>
                              <Text type="secondary" style={{ fontSize: '12px' }}>
                                {new Date(categoryFeaturedPost.publishedAt).toLocaleDateString('en-US', {
                                  day: 'numeric',
                                  month: 'short',
                                  year: 'numeric',
                                })}
                              </Text>
                            </div>
                          </div>
                        </Card>
                      </Link>
                    </Col>
                  )}

                  <Col xs={24} md={8}>
                    <Row gutter={[16, 16]}>
                      {categorySmallerPosts1.map((post) => {
                        const mediaBlock = post.layout?.find((block) => block.blockType === 'mediaBlock');
                        const imageUrl = mediaBlock?.media?.url;
                        const imageAlt = mediaBlock?.media?.alt || post.title;

                        return (
                          <Col xs={24} key={post.id}>
                            <Link href={`${postBaseUrl}/${post.slug}`}>
                              <Card
                                hoverable
                                style={{
                                  borderRadius: '8px',
                                  boxShadow: '0 2px 8px rgba(0, 0, 0, 0.15)',
                                  border: 'none',
                                  display: 'flex',
                                  alignItems: 'center',
                                }}
                                bodyStyle={{ padding: '8px', display: 'flex', alignItems: 'center' }}
                              >
                                <div style={{ flex: 1 }}>
                                  <div style={{ ...clampStyle, fontSize: '14px', fontWeight: 'bold' }}>
                                    {post.title}
                                  </div>
                                  <div style={{ marginTop: '4px' }}>
                                    <Space size={4}>
                                      <Text type="secondary" style={{ fontSize: '12px' }}>
                                        {new Date(post.publishedAt).toLocaleDateString('en-US', {
                                          day: 'numeric',
                                          month: 'short',
                                          year: 'numeric',
                                        })}
                                      </Text>
                                      <ClockCircleOutlined style={{ fontSize: '12px', color: '#8c8c8c' }} />
                                      <Text type="secondary" style={{ fontSize: '12px' }}>
                                        5 Min Read
                                      </Text>
                                    </Space>
                                  </div>
                                </div>
                                {imageUrl ? (
                                  <img
                                    alt={imageAlt}
                                    src={imageUrl}
                                    style={{
                                      width: '80px',
                                      height: '60px',
                                      objectFit: 'cover',
                                      borderRadius: '4px',
                                      marginLeft: '12px',
                                    }}
                                  />
                                ) : (
                                  <div
                                    style={{
                                      width: '80px',
                                      height: '60px',
                                      backgroundColor: '#f0f0f0',
                                      borderRadius: '4px',
                                      marginLeft: '12px',
                                      display: 'flex',
                                      alignItems: 'center',
                                      justifyContent: 'center',
                                    }}
                                  >
                                    <Text type="secondary" style={{ fontSize: '12px' }}>
                                      No Image
                                    </Text>
                                  </div>
                                )}
                              </Card>
                            </Link>
                          </Col>
                        );
                      })}
                    </Row>
                  </Col>

                  <Col xs={24} md={8}>
                    <Row gutter={[16, 16]}>
                      {categorySmallerPosts2.map((post) => {
                        const mediaBlock = post.layout?.find((block) => block.blockType === 'mediaBlock');
                        const imageUrl = mediaBlock?.media?.url;
                        const imageAlt = mediaBlock?.media?.alt || post.title;

                        return (
                          <Col xs={24} key={post.id}>
                            <Link href={`${postBaseUrl}/${post.slug}`}>
                              <Card
                                hoverable
                                style={{
                                  borderRadius: '8px',
                                  boxShadow: '0 2px 8px rgba(0, 0, 0, 0.15)',
                                  border: 'none',
                                  display: 'flex',
                                  alignItems: 'center',
                                }}
                                bodyStyle={{ padding: '8px', display: 'flex', alignItems: 'center' }}
                              >
                                <div style={{ flex: 1 }}>
                                  <div style={{ ...clampStyle, fontSize: '14px', fontWeight: 'bold' }}>
                                    {post.title}
                                  </div>
                                  <div style={{ marginTop: '4px' }}>
                                    <Space size={4}>
                                      <Text type="secondary" style={{ fontSize: '12px' }}>
                                        {new Date(post.publishedAt).toLocaleDateString('en-US', {
                                          day: 'numeric',
                                          month: 'short',
                                          year: 'numeric',
                                        })}
                                      </Text>
                                      <ClockCircleOutlined style={{ fontSize: '12px', color: '8c8c8c' }} />
                                      <Text type="secondary" style={{ fontSize: '12px' }}>
                                        5 Min Read
                                      </Text>
                                    </Space>
                                  </div>
                                </div>
                                {imageUrl ? (
                                  <img
                                    alt={imageAlt}
                                    src={imageUrl}
                                    style={{
                                      width: '80px',
                                      height: '60px',
                                      objectFit: 'cover',
                                      borderRadius: '4px',
                                      marginLeft: '12px',
                                    }}
                                  />
                                ) : (
                                  <div
                                    style={{
                                      width: '80px',
                                      height: '60px',
                                      backgroundColor: '#f0f0f0',
                                      borderRadius: '4px',
                                      marginLeft: '12px',
                                      display: 'flex',
                                      alignItems: 'center',
                                      justifyContent: 'center',
                                    }}
                                  >
                                    <Text type="secondary" style={{ fontSize: '12px' }}>
                                      No Image
                                    </Text>
                                  </div>
                                )}
                              </Card>
                            </Link>
                          </Col>
                        );
                      })}
                    </Row>
                  </Col>
                </Row>
              </section>
            );
          })
        )
      )}
    </div>
  );
}