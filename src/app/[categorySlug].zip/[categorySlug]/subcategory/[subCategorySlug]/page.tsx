// src/app/[categorySlug]/subcategory/[subCategorySlug]/page.tsx

import axios from "axios";
import { notFound } from "next/navigation";

// Type definitions
type Category = {
  id: string;
  title: string;
  slug: string;
  parent?: { id: string; slug: string; title: string } | string;
};

// API base URL
const apiUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:3000";

// Cache for categories
const categoryCache = new Map<string, Category>();

// Fetch a category by slug
async function fetchCategoryBySlug(slug: string): Promise<Category | null> {
  if (categoryCache.has(slug)) {
    console.log(`Returning cached category for slug: ${slug}`);
    return categoryCache.get(slug)!;
  }

  try {
    const response = await axios.get(
      `${apiUrl}/api/categories?where[slug][equals]=${slug}&depth=2`
    );
    const category = response.data.docs[0] || null;
    if (category) {
      categoryCache.set(slug, category);
      console.log(`Fetched and cached category ${slug}:`, category);
    } else {
      console.log(`No category found for slug: ${slug}`);
    }
    return category;
  } catch (error) {
    console.error(
      `Error fetching category with slug ${slug}:`,
      error.response?.data || error.message
    );
    return null;
  }
}

// Fetch parent category details by ID
async function fetchParentCategory(
  parentId: string
): Promise<{ slug: string; title: string } | null> {
  try {
    const res = await axios.get(`${apiUrl}/api/categories/${parentId}?depth=1`);
    const parentCategory = res.data || null;
    if (!parentCategory) {
      console.log(`No parent category found for ID: ${parentId}`);
      return null;
    }
    console.log(`Fetched parent category for ID ${parentId}:`, parentCategory);
    return {
      slug: parentCategory.slug || "uncategorized",
      title: parentCategory.title || "Uncategorized",
    };
  } catch (err) {
    console.error(
      `Error fetching parent category with ID ${parentId}:`,
      err.response?.data || err.message
    );
    return null;
  }
}

// Main SubCategoryPage component
export default async function SubCategoryPage({
  params,
}: {
  params: Promise<{ categorySlug: string; subCategorySlug: string }>;
}) {
  console.log("Entering SubCategoryPage component");

  // Await params to resolve the Promise
  const { categorySlug, subCategorySlug } = await params;
  console.log(`Handling subcategory page for ${categorySlug}/${subCategorySlug}`);

  // Fetch the subcategory
  const subCategory = await fetchCategoryBySlug(subCategorySlug);
  if (!subCategory) {
    console.log(`Subcategory not found for slug: ${subCategorySlug}`);
    notFound();
  }

  // Verify the parent category
  let parentCategorySlug = "uncategorized";
  let parentCategoryTitle = "Uncategorized";

  if (subCategory.parent) {
    const parent = typeof subCategory.parent === "string"
      ? await fetchParentCategory(subCategory.parent)
      : subCategory.parent;
    if (parent) {
      parentCategorySlug = parent.slug;
      parentCategoryTitle = parent.title;
      console.log(
        `Parent category for subcategory ${subCategorySlug}: ${parentCategorySlug} (${parentCategoryTitle})`
      );
    } else {
      console.log(
        `Parent category not found for subcategory ${subCategorySlug}, using defaults`
      );
    }

    // Log mismatch but proceed with rendering
    if (parentCategorySlug !== categorySlug) {
      console.warn(
        `Parent category mismatch: expected ${categorySlug}, but found ${parentCategorySlug} for subcategory ${subCategorySlug}. Proceeding with rendering.`
      );
    }
  } else {
    console.log(
      `Subcategory ${subCategorySlug} has no parent, this route should not be used for top-level categories`
    );
    notFound();
  }

  // If we reach here, render a simple page to confirm the route works
  return (
    <div>
      <h1>Subcategory: {subCategory.title}</h1>
      <p>Parent Category: {parentCategoryTitle}</p>
      <p>URL: {categorySlug}/{subCategorySlug}</p>
      <p>This is a test page to confirm the subcategory route is working.</p>
    </div>
  );
}

// Generate static parameters for Next.js static generation
export async function generateStaticParams() {
  console.log("Entering generateStaticParams for subcategory page");

  try {
    const res = await axios.get(
      `${apiUrl}/api/categories?where[parent][exists]=true&limit=100&depth=2`
    );
    const categories = res.data.docs || [];
    console.log(`Fetched ${categories.length} subcategories for static generation`);

    const params = [];
    for (const category of categories) {
      const parent = typeof category.parent === "string"
        ? await fetchParentCategory(category.parent)
        : category.parent;
      if (parent) {
        const param = {
          categorySlug: parent.slug,
          subCategorySlug: category.slug,
        };
        params.push(param);
        console.log(`Generated static param: ${parent.slug}/${category.slug}`);
      } else {
        console.log(`Skipping category ${category.slug}: no parent found`);
      }
    }

    console.log("Generated static params for subcategories:", params);
    return params;
  } catch (error) {
    console.error(
      "Error generating static params for subcategories:",
      error.response?.data || error.message
    );
    return [];
  }
}